import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private loginUrl = 'https://localhost:44313/api/v1.0/moviebooking/login';
  private forgotPasswordUrl = 'https://localhost:44313/api/v1.0/moviebooking/';
  private adminLoginUrl = 'https://localhost:44313/api/v1.0/moviebooking/adminlogin';

  // BehaviorSubject to track login status
  private loginStatusSubject = new BehaviorSubject<boolean>(this.isLoggedIn());
  isLoggedIn$ = this.loginStatusSubject.asObservable();
  private adminStatusSubject = new BehaviorSubject<boolean>(this.isAdminLoggedIn());
  isAdminLoggedIn$ = this.adminStatusSubject.asObservable();

  constructor(private http: HttpClient) {}

  login(loginId: string, password: string): Observable<string> {
    const params = new HttpParams()
      .set('Login_Id', loginId)
      .set('Password', password);
    return this.http.get<string>(this.loginUrl, { params, responseType: 'text' as 'json' });
  }

  adminLogin(adminLoginId: string, adminPassword: string): Observable<string> {
    const params = new HttpParams()
      .set('admin_login_id', adminLoginId)
      .set('admin_password', adminPassword);
    return this.http.get<string>(this.adminLoginUrl, { params, responseType: 'text' as 'json' });
  }

  forgotPassword(username: string): Observable<string> {
    return this.http.get<string>(`${this.forgotPasswordUrl}${username}/forgot`, { responseType: 'text' as 'json' });
  }

  // Method to update login status
  updateLoginStatus(isLoggedIn: boolean): void {
    localStorage.setItem('isLoggedIn', JSON.stringify(isLoggedIn));
    this.loginStatusSubject.next(isLoggedIn); // Emit new login status
  }

  // Method to check login status
  isLoggedIn(): boolean {
    return JSON.parse(localStorage.getItem('isLoggedIn') || 'false');
  }

  // Method to update admin login status
  updateAdminStatus(isAdmin: boolean): void {
    localStorage.setItem('isAdminLoggedIn', JSON.stringify(isAdmin));
    this.adminStatusSubject.next(isAdmin); // Emit new admin login status
  }

  isAdminLoggedIn(): boolean {
    return JSON.parse(localStorage.getItem('isAdminLoggedIn') || 'false');
  }

  updatePassword(updateDetails: any): Observable<string> {
    return this.http.put<string>(`${this.loginUrl}updatepassword`, updateDetails, { responseType: 'text' as 'json' });
  }
}
