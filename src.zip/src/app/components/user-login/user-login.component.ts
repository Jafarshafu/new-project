import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  loginForm: FormGroup;
  loginError: string | null = null;
  isLoggedIn: boolean = false; // Track login status

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      loginId: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  ngOnInit(): void {}

  onSubmit(): void {
    if (this.loginForm.valid) {
      const { loginId, password } = this.loginForm.value;

      this.authService.login(loginId, password).subscribe({
        next: (response) => {
          if (response === "Login Successful") {
            this.isLoggedIn = true; // Set login status
            this.loginError = null; // Clear any previous errors
            
            // Redirect to home page
            this.router.navigate(['/home']);
          } else {
            this.loginError = response;
          }
        },
        error: (err) => {
          console.error('Login failed', err);
          this.loginError = 'An error occurred. Please try again.';
        }
      });
    }
  }

  forgotPassword(): void {
    const loginId = this.loginForm.get('loginId')?.value;
    if (loginId) {
      this.authService.forgotPassword(loginId).subscribe({
        next: (response) => {
          alert(`Your password is: ${response}`); // Alert the user with the password
        },
        error: (err) => {
          console.error('Failed to fetch password', err);
          alert('An error occurred while fetching the password.');
        }
      });
    } else {
      alert('Please enter your Login ID.');
    }
  }
}


  // // updatePassword(): void {
  // //   if (this.updatePasswordForm.valid) {
  // //     const { currentPassword, newPassword, confirmNewPassword } = this.updatePasswordForm.value;

  // //     // Check if new password matches confirm password
  // //     if (newPassword !== confirmNewPassword) {
  // //       this.updateError = "New password and confirm password do not match.";
  // //       return;
  // //     }

  // //     const updatePasswordDetails = {
  // //       Login_Id: this.loginForm.value.loginId,
  // //       CurrentPassword: currentPassword,
  // //       NewPassword: newPassword
  // //     };

  // //     this.authService.updatePassword(updatePasswordDetails).subscribe({
  // //       next: (response) => {
  // //         this.updateSuccess = response;
  // //         this.updateError = null;
  // //         this.updatePasswordForm.reset();
  // //       },
  // //       error: (err) => {
  // //         console.error('Update password failed', err);
  // //         this.updateError = 'An error occurred. Please try again.';
  // //         this.updateSuccess = null;
  // //       }
  //    });
  //   }
  // }
//}
