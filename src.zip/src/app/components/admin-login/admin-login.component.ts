import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
  loginForm: FormGroup;
  loginError: string | null = null;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      adminLoginId: ['', Validators.required],
      adminPassword: ['', Validators.required]
    });
  }

  ngOnInit(): void {}

  onSubmit(): void {
    if (this.loginForm.valid) {
      const { adminLoginId, adminPassword } = this.loginForm.value;

      this.authService.adminLogin(adminLoginId, adminPassword).subscribe({
        next: (response) => {
          if (response === "Login Successful") {
            this.authService.updateLoginStatus(true); // Update login status in AuthService
            this.router.navigate(['/home']); // Navigate to home
          } else {
            this.loginError = response;
          }
        },
        error: (err) => {
          console.error('Login failed', err);
          this.loginError = 'An error occurred. Please try again.';
        }
      });
    }
  }
}
