import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  movies = [
    { title: 'Movie 1', image: 'assets/logo.png' },
    { title: 'Movie 2', image: 'assets/logo.png' },
    { title: 'Movie 3', image: 'assets/logo.png' },
    { title: 'Movie 4', image: 'assets/logo.png' },
  ];
  isUserLoggedIn = false;

  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    // Subscribe to the login status
    this.authService.isLoggedIn$.subscribe(loggedIn => {
      this.isUserLoggedIn = loggedIn;
    });
  }

  onBookTicket(movieTitle: string): void {
    if (this.isUserLoggedIn) {
      // Logic to book a ticket
      console.log(`Booking ticket for ${movieTitle}`);
      alert(`Ticket booked for ${movieTitle}!`);
    } else {
      alert('Please log in to book a ticket.');
    }
  }
}
