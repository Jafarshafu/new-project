export interface User {
    First_Name: string;
    Last_Name: string;
    Email: string;
    Login_Id: string;
    Password: string;
    Confrim_Password: string; // Optional, if you want to validate it
  }
  