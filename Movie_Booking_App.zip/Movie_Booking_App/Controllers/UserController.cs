﻿using Microsoft.AspNetCore.Mvc;
using Movie_Booking_App.Model;
using Movie_Booking_App.Repositories;

namespace Movie_Booking_App.Controllers
{
    [Route("api/v1.0/moviebooking")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _userrepository;
        private readonly ILogger<UserController> _logger;
        public UserController(IUserRepository userrepository, ILogger<UserController> logger)
        {
            _logger= logger;
            _userrepository = userrepository;
        }
        /// <summary>
        /// New User Registration
        /// </summary>
        /// <param name="_newuserdetails"></param>
        /// <returns>Registration conformation</returns>
        [HttpPost]
        [Route("register")]
        public async Task<IActionResult> Register([FromBody] User _newuserdetails)
        {
            if(_newuserdetails == null)
            {
                _logger.LogError("User Registration controller: user details should not be empty");
                return BadRequest("user details should not be empty");
            }
            else
            {
                _logger.LogDebug($"New User Registration {_newuserdetails.Email}");
                var result = await _userrepository.NewUserRegistration(_newuserdetails);
                return new JsonResult(result.ToString());
            }
            
        }
        /// <summary>
        /// Fetching password for forget password
        /// </summary>
        /// <param name="Login_Id"></param>
        /// <returns>Password</returns>
        [HttpGet]
        [Route("{username}/forgot")]
        public async Task<string> Forgotpassword(string username)
        {
            if(username == null)
            {
                _logger.LogError("User Forgotpassword controller: user Login_id should not be empty");
                return "Login Id should not be empty";

            }
            else
            {
                _logger.LogInformation($"Fetching password of {username}");
                _logger.LogDebug($"{username} password");
                return await _userrepository.ForgotPassword(username);

            }
        }
        /// <summary>
        /// User Login
        /// </summary>
        /// <param name="Login_Id"></param>
        /// <param name="Password"></param>
        /// <returns>Login status</returns>
        [HttpGet]
        [Route("login")]
        public async Task<string> Login(string Login_Id, string Password)
        {
            if (Login_Id == null || Password == null)
            {
                _logger.LogError("User Login controller: user Login_id or password should not be empty");
                return "Login Id or password should not be empty";

            }
            else
            {
                _logger.LogInformation($"{Login_Id}:{Password} login check");   
                _logger.LogDebug(Login_Id+ "Login check with " + Password);
                var result = await _userrepository.UserLoginCheck(Login_Id, Password);
                return result.ToString();
            }
            
        }


        /// <summary>
        /// Update new password
        /// </summary>
        /// <param name="_userdetails"></param>
        /// <returns>Update status</returns>
        [HttpPut("updatepassword")]
        public async Task<IActionResult> UpdatePassword([FromBody] UserUpdatePassword _userdetails)
        {
            // Check if the DTO is null
            if (_userdetails == null)
            {
                _logger.LogError("User updatepassword controller: user details should not be empty.");
                return BadRequest("User details should not be empty.");
            }

            _logger.LogInformation("Updating password for user: {LoginId}", _userdetails.Login_Id);

            // Call the repository method to update the password
            var result = await _userrepository.UpdatePassword(_userdetails);

            if (string.IsNullOrWhiteSpace(result))
            {
                // If no message is returned, it's likely an error occurred
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while updating the password.");
            }
            else if (result.Contains("successfully"))
            {
                // If the password update was successful
                return Ok(result);
            }
            else
            {
                // If there was an error or specific failure message
                return BadRequest(result);
            }
        }


    }
}
