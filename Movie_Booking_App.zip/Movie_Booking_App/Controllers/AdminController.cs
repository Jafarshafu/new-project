﻿using Microsoft.AspNetCore.Mvc;
using Movie_Booking_App.Repositories;

namespace Movie_Booking_App.Controllers
{
    [Route("api/v1.0/moviebooking")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IMovieBookingRepository _moviebookingrepository;
        private readonly IUserRepository _userrepository;

        private readonly ILogger<AdminController> _logger;
        public AdminController(IMovieBookingRepository moviebookingrepository,IUserRepository userRepository, ILogger<AdminController> logger)
        {
            _moviebookingrepository = moviebookingrepository;
            _userrepository = userRepository;
            _logger = logger; 
        }

        /// <summary>
        /// Admin Login
        /// </summary>
        /// <param name="Login_Id"></param>
        /// <param name="Password"></param>
        /// <returns>Login status</returns>
        [HttpGet]
        [Route("adminlogin")]
        public async Task<string> Admin_Login(string admin_login_id, string admin_password)
        {
            if (admin_login_id == null || admin_password == null)
            {
                _logger.LogError("User Login controller: user Login_id or password should not be empty");
                return "Login Id or password should not be empty";

            }
            else
            {
                _logger.LogInformation($"{admin_login_id}:{admin_password} login check");
                _logger.LogDebug(admin_login_id + "Login check with " + admin_password);
                var result = await _userrepository.AdminLoginCheck(admin_login_id, admin_password);
                return result.ToString();
            }

        }
        /// <summary>
        /// To fetch booked tickets data
        /// </summary>
        /// <param name="moviename"></param>
        /// <returns>Booked Tickets</returns>
        [HttpGet]
        [Route("bookedtickets")]
        public async Task<Int32> BookedTickets(string moviename)
        {
            if (moviename == null)
            {
                _logger.LogError("moviename information is null");
                return 0;
            }
            else
            {
                _logger.LogInformation("Ticket booking");
                var result = await _moviebookingrepository.BookedTickets(moviename);
                return result;
            }
            
        }

        /// <summary>
        /// Update ticket availability
        /// </summary>
        /// <param name="moviename"></param>
        /// <returns>Update Tickets confirmation</returns>
        [HttpPut]
        [Route("<moviename>/update")]
        public async Task<string> UpdateTicketAvailability([FromBody] string moviename)
        {
            if (moviename == null)
            {
                _logger.LogError("moviename information is null");
                return "Please provide movie name";
            }
            else
            {
                _logger.LogInformation("Ticket update");
                var result = await _moviebookingrepository.UpdateMovieTicketAvailability(moviename);
                return result;
            }
            
        }



    }
}
