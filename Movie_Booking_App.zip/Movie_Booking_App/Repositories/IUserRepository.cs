﻿using MongoDB.Bson;
using Movie_Booking_App.Model;

namespace Movie_Booking_App.Repositories
{
    public interface IUserRepository
    {

        Task<string> NewUserRegistration(User userDetails);
        Task<string> UserLoginCheck(string login_Id, string password);
        Task<string> ForgotPassword(string login_Id);
        //Task<string> UpdatePassword(string login_Id, string newpassword);
        Task<string> AdminLoginCheck(string login_Id, string password);
        Task<string> UpdatePassword(UserUpdatePassword updatePasswordDto);
        //Task<UserRepository> Get(ObjectId objectId);
        //Task<IEnumerable<UserRepository>> GetByObjectLoginId(UserRepository userDetails);
        //Task<IEnumerable<UserRepository>> GetAll();   

        //Task Delete(ObjectId objectId);
        //Task<bool> Update(ObjectId objectId, UserRepository userDetails);
    }
}
