﻿using Movie_Booking_App.Model;
using MongoDB.Driver;
using Movie_Booking_App.Controllers;

namespace Movie_Booking_App.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly IMongoCollection<User> _users;
        private readonly IMongoCollection<Admin> _admin;
        private readonly IConfiguration _configuration;
        public UserRepository(IMongoClient client, IConfiguration configuration)
        {
            _configuration = configuration;
            string? dbNmae = configuration["Database:Name"];
            var database = client.GetDatabase("MovieBookingDB");
            var collection = database.GetCollection<User>(nameof(User));
            var admincollection = database.GetCollection<Admin>(nameof(Admin));
            _admin = admincollection;
            _users = collection;
            _configuration = configuration;
        }
        /// <summary>
        /// New User Registration
        /// </summary>
        /// <param name="userDetails"></param>
        /// <returns>User registration statuss</returns>
        public async Task<string> NewUserRegistration(User userDetails)
        {
            try
            {
                var existingEmail = await IsEmailExist(userDetails.Email);
                var existingId = await IsLogin_IdExist(userDetails.Login_Id);
                if ((existingEmail || existingId) == false)
                {
                    await _users.InsertOneAsync(userDetails);
                    return "User Registered Successfully";
                }
                else if (existingEmail)
                    return "Email Id already exist";
                else
                    return "Login id already exist";
            }
             catch (Exception ex)
            {
                Console.WriteLine("Exception while checking for Loginid exist", ex);
                return "";
            }
        }
        /// <summary>
        /// TO return password if forgoit
        /// </summary>
        /// <param name="Login_Id"></param>
        /// <returns>Existing Password</returns>
        public async Task<string> ForgotPassword(string Login_Id)
        {
            try
            {
                var forgotpassword_filter = Builders<User>.Filter.Eq(x => x.Login_Id, Login_Id);
                var forgotpassword_filter_result = _users.Find(forgotpassword_filter).FirstOrDefaultAsync().Result.Password;
                if (forgotpassword_filter_result != null)
                    return $"Your Password is {forgotpassword_filter_result}";
                else
                    return " Login_Id doesn't exist";
            }
             catch (Exception ex)
            {
                Console.WriteLine("Exception while checking for Loginid exist", ex);
                return "";
            }
        }
        /// <summary>
        /// User Login
        /// </summary>
        /// <param name="Login_Id"></param>
        /// <param name="Password"></param>
        /// <returns>Login status</returns>
        public async Task<string> UserLoginCheck(string Login_Id , string Password)
        {
            try
            {
                var login_filter = Builders<User>.Filter.Eq(u => u.Login_Id, Login_Id) & Builders<User>.Filter.Eq(u => u.Password, Password);
                var login_result = await _users.Find(login_filter).FirstOrDefaultAsync();
                if (login_result != null)
                    return "Login Successful";
                else
                    return "Please enter valid credentials";
            }
             catch (Exception ex)
            {
                Console.WriteLine("Exception while checking for Loginid exist", ex);
                return "";
            }
        }

        /// <summary>
        /// Admin Login
        /// </summary>
        /// <param name="Login_Id"></param>
        /// <param name="Password"></param>
        /// <returns>Login status</returns>
        public async Task<string> AdminLoginCheck(string admin_login_id, string admin_password)
        {
            try
            {
                var login_filter = Builders<Admin>.Filter.Eq(u => u.admin_login_id, admin_login_id) & Builders<Admin>.Filter.Eq(u => u.admin_password, admin_password);
                var login_result = await _admin.Find(login_filter).FirstOrDefaultAsync();
                if (login_result != null)
                    return "Login Successful";
                else
                    return "Please enter valid credentials";
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception while checking for Loginid exist", ex);
                return "";
            }
        }
        /// <summary>
        /// Update Existing password by user
        /// </summary>
        /// <returns>Password updation status</returns>
        public async Task<string> UpdatePassword(UserUpdatePassword updatePasswordDto)
        {
            try
            {
                // Check if the DTO is null
                if (updatePasswordDto == null)
                {
                    return "Update password details cannot be null.";
                }

                // Check if CurrentPassword, NewPassword, and ConfirmNewPassword are not null or empty
                if (string.IsNullOrWhiteSpace(updatePasswordDto.CurrentPassword) ||
                    string.IsNullOrWhiteSpace(updatePasswordDto.NewPassword) ||
                    string.IsNullOrWhiteSpace(updatePasswordDto.ConfirmNewPassword))
                {
                    return "CurrentPassword, NewPassword, and ConfirmNewPassword cannot be null or empty.";
                }

                // Create filter to find the user by Login_Id
                var filter = Builders<User>.Filter.Eq(u => u.Login_Id, updatePasswordDto.Login_Id);

                // Check if user exists
                var user = await _users.Find(filter).FirstOrDefaultAsync();
                if (user == null)
                {
                    return "User not found.";
                }

                // Verify the current password
                if (user.Password != updatePasswordDto.CurrentPassword)
                {
                    return "Current password is incorrect.";
                }

                // Check if new password matches confirm password
                if (updatePasswordDto.NewPassword != updatePasswordDto.ConfirmNewPassword)
                {
                    return "New password and confirm password do not match.";
                }

                // Prepare the update definition
                var update = Builders<User>.Update.Set(u => u.Password, updatePasswordDto.NewPassword);

                // Execute the update
                var result = await _users.UpdateOneAsync(filter, update);

                if (result.ModifiedCount > 0)
                {
                    return "Password updated successfully.";
                }
                else
                {
                    return "No changes were made to the password.";
                }
            }
            catch (Exception ex)
            {
                // Log the exception (consider using a logging framework)
                Console.WriteLine("Exception while updating password: ", ex);
                return "An error occurred while updating the password.";
            }
        }

        /// <summary>
        /// To check mail id already exist
        /// </summary>
        /// <param name="Email"></param>
        /// <returns>true if exist</returns>
        private async Task<bool> IsEmailExist(string Email)
        {
            try
            {
                var emailfilter = Builders<User>.Filter.Eq(e => e.Email, Email);
                return await _users.Find(emailfilter).AnyAsync();
            }
             catch (Exception ex)
            {
                Console.WriteLine("Exception while checking for Loginid exist", ex);
                return false;
            }
        }
        /// <summary>
        /// TO check Login Id already exist
        /// </summary>
        /// <param name="Login_Id"></param>
        /// <returns> true if exist</returns>
        private async Task<bool> IsLogin_IdExist(string Login_Id)
        {
            try
            {
                var emailfilter = Builders<User>.Filter.Eq(e => e.Login_Id, Login_Id);
                return await _users.Find(emailfilter).AnyAsync();
            }
            catch(Exception ex) 
            {
                Console.WriteLine("Exception while checking for Loginid exist",ex);
                return false;
            }
        }
    }
}
