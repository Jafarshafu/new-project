﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Movie_Booking_App.Model
{
    public class Admin
    {
        [BsonId] // This attribute specifies that this property is the primary key
        [BsonRepresentation(BsonType.ObjectId)] // This indicates that the property is an ObjectId
        public string Id { get; set; } // Corresponds to the "_id" field in MongoDB

        public string admin_login_id { get; set; }
        public string admin_password { get; set; }
    }
}
