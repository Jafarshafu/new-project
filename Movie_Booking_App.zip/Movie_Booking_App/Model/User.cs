﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.ComponentModel.DataAnnotations;

namespace Movie_Booking_App.Model
{
    public class User
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public ObjectId objectId{ get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Please provide your First Name")]
        [MinLength(1,ErrorMessage = "Frist name cannot be empty")]
        [StringLength(20, ErrorMessage = "First name cannot be greater that 20 characters")]

        public string First_Name { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Please provide your Email")]
        [MinLength(1, ErrorMessage = "Email cannot be empty")]
        [StringLength(20, ErrorMessage = "Email cannot be greater that 20 characters")]

        public string Last_Name { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Please provide your Email")]
        [EmailAddress] 
        [MinLength(1, ErrorMessage = "Email cannot be empty")]
        [StringLength(20, ErrorMessage = "Email cannot be greater that 20 characters")]
        public string Email { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Please provide your Login_Id")]
        [MinLength(1, ErrorMessage = "Login_Id cannot be empty")]
        [StringLength(20, ErrorMessage = "Login_Id cannot be greater that 20 characters")]
        public string Login_Id { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Please provide your Password")]
        [MinLength(1, ErrorMessage = "Password cannot be empty")]
        [StringLength(20, ErrorMessage = "Password cannot be greater that 20 characters")]
        public string Password { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Please provide your Confrim_Password")]
        [MinLength(1, ErrorMessage = "Confrim_Password cannot be empty")]
        [Compare("Password", ErrorMessage ="Password and Confrim Password mismatch")]
        public string Confrim_Password { get; set; }
        

    }
}
