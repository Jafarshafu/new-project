﻿using System.ComponentModel.DataAnnotations;

namespace Movie_Booking_App.Model
{
    public class UserUpdatePassword
    {
        [Required(AllowEmptyStrings = false, ErrorMessage = "Please provide your Login_Id")]
        [MinLength(1, ErrorMessage = "Login_Id cannot be empty")]
        [StringLength(20, ErrorMessage = "Login_Id cannot be greater that 20 characters")]
        public string Login_Id { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Please provide your current Password")]
        public string CurrentPassword { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Please provide your new Password")]
        [MinLength(1, ErrorMessage = "New Password cannot be empty")]
        [StringLength(20, ErrorMessage = "New Password cannot be greater than 20 characters")]
        public string NewPassword { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Please provide your Confirm New Password")]
        [Compare("NewPassword", ErrorMessage = "New Password and Confirm New Password mismatch")]
        public string ConfirmNewPassword { get; set; }
    }
}
