﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace Movie_Booking_App.Model
{
    public class Movie
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public ObjectId objectId { get; set; }
        public string Movie_Name { get; set; }
        public string Theatre_Name { get; set; }
        public string Ticket_Status { get; set; }
        public int Total_Tickets { get; set; }
        public int Booking_Tickets { get; set; }
        public int No_of_Tickets_Available { get; set; }
        public int seat_Number { get; set; }
        public DateTime Show_Time { get; set; }
    }
}
